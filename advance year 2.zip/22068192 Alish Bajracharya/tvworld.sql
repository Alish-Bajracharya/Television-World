-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2024 at 07:29 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tvworld`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `title`, `description`) VALUES
(1, 'book', 'book\r\n'),
(2, 'book', 'book\r\n'),
(3, 'book', 'book\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `orderId` int(20) NOT NULL,
  `orderDate` date NOT NULL,
  `quantity` int(20) NOT NULL,
  `Totalamt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(255) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `category` varchar(255) NOT NULL,
  `productImage` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `productName`, `price`, `category`, `productImage`) VALUES
(11, 'Haier', 200000, '4k', 'img1.jpg'),
(14, 'LG', 9850, 'LED ', 'img2.jpg'),
(19, 'Panasonic', 30003, 'QLED', 'img3.jpg'),
(20, 'Sony', 456000, 'Television', 'img4.jpg'),
(25, 'Samsung', 50000, '4K LED', 'img6.jpg'),
(26, 'LG', 50000, 'HD', 'img2.jpg'),
(27, 'Panasonic ULtra', 8500, 'ULTra HD', 'img3.jpg'),
(28, 'Sony', 8000, 'Big TV', 'img3.jpg'),
(29, 'TCL QLED', 9000, 'Medium', 'img5.jpg'),
(30, 'Sony', 90000, 'Small', 'img3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(255) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `utype` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `username`, `password`, `email`, `utype`) VALUES
(1, 'Student', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', '1@gmail.com', 'customer'),
(2, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin@gmail.com', 'admin'),
(3, 'alish', '2b614fd4b8cfe5847610cfe479a3dc018733e012', 'Anacoda@gmai.com', 'customer'),
(4, 'bn', '5c2dd944dde9e08881bef0894fe7b22a5c9c4b06', 'hj', 'j'),
(5, 'jayesh', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'j@gmail.com', 'customer'),
(6, 'alish', 'f10e2821bbbea527ea02200352313bc059445190', 'asd', 'asd'),
(7, 'angel', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'angelish1105@gmail.com', 'customer'),
(8, 'angel', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', 'angelish1105@gmail.com', 'customer'),
(9, 'abc', '5ddd69840dc326d8b2968625056fe6cd5f978021', 'abc@gmail.com', 'customer'),
(10, 'alu', '39f9ae3dcec293d645243b5d26ab8252c2d2eb64', 'alish@gmail.com', 'admin'),
(11, 'abcd', '0d04fa9edcd3703d599e4fab771b4960673ec95c', 'a@gmail.com', 'customer'),
(12, 'an', '804cf2e8097dce9b472e80ec056dcb5de050f22d', 'an@gmail.com', 'customer'),
(13, 'lyaamlyaaam', '77e9f69fa28b58366013c8869dada1663afc40e8', '9@gmail.com', 'customer'),
(14, 'aesha', '50bc45ac333f32970fa8e088c4075ff08db181d3', 'ae@gmail.com', 'customer'),
(15, 'aesha', '50bc45ac333f32970fa8e088c4075ff08db181d3', 'ae@gmail.com', 'customer'),
(16, 'Alish Bajracharya', '74ebf7c36f0f8e78ad38bdb8ae614abb03df33b8', 'bajracharya.alish@gmail.com', 'Customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
